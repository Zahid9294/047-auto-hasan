package com.autoaccept.store047.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences("auto_accept_047_prefs", Context.MODE_PRIVATE)

    private val _isAutomationEnabled = MutableStateFlow(prefs.getBoolean("key_automation_enabled", false))
    val isAutomationEnabled: StateFlow<Boolean> = _isAutomationEnabled.asStateFlow()

    private val _storeCode = MutableStateFlow(prefs.getString("key_store_code", "047") ?: "047")
    val storeCode: StateFlow<String> = _storeCode.asStateFlow()

    private val _targetPackage = MutableStateFlow(prefs.getString("key_target_package", "") ?: "")
    val targetPackage: StateFlow<String> = _targetPackage.asStateFlow()

    fun setAutomationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("key_automation_enabled", enabled).apply()
        _isAutomationEnabled.value = enabled
    }

    fun setStoreCode(code: String) {
        prefs.edit().putString("key_store_code", code.trim()).apply()
        _storeCode.value = code.trim()
    }

    fun setTargetPackage(pkg: String) {
        prefs.edit().putString("key_target_package", pkg.trim()).apply()
        _targetPackage.value = pkg.trim()
    }

    companion object {
        @Volatile
        private var INSTANCE: PreferencesManager? = null
        fun getInstance(context: Context): PreferencesManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PreferencesManager(context).also { INSTANCE = it }
            }
        }
    }
}
