package com.autoaccept.store047.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.autoaccept.store047.data.LogLevel
import com.autoaccept.store047.data.LogRepository
import com.autoaccept.store047.data.PreferencesManager
import com.autoaccept.store047.engine.AutomationEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AutoAcceptAccessibilityService : AccessibilityService() {

    private lateinit var prefsManager: PreferencesManager
    private val automationEngine = AutomationEngine()

    companion object {
        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefsManager = PreferencesManager.getInstance(this)
        _isServiceConnected.value = true
        LogRepository.addLog("Accessibility Service connected successfully.", LogLevel.SUCCESS)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        if (!prefsManager.isAutomationEnabled.value) {
            return
        }

        val eventType = event.eventType
        if (eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            return
        }

        val targetPackage = prefsManager.targetPackage.value
        val eventPackage = event.packageName?.toString() ?: ""

        if (targetPackage.isNotBlank() && !eventPackage.equals(targetPackage, ignoreCase = true)) {
            return
        }

        val rootNode = rootInActiveWindow ?: return
        val storeCode = prefsManager.storeCode.value

        try {
            automationEngine.processWindow(
                rootNode = rootNode,
                storeCode = storeCode,
                targetPackage = targetPackage
            )
        } catch (e: Exception) {
            LogRepository.addLog("Error during screen processing: ${e.localizedMessage ?: "Unknown"}", LogLevel.WARNING)
        }
    }

    override fun onInterrupt() {
        LogRepository.addLog("Accessibility Service interrupted.", LogLevel.WARNING)
    }

    override fun onDestroy() {
        super.onDestroy()
        _isServiceConnected.value = false
        LogRepository.addLog("Accessibility Service disconnected.", LogLevel.INFO)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        _isServiceConnected.value = false
        return super.onUnbind(intent)
    }
}
